-- FundLedger / Supabase setup
-- Run this entire file in Supabase SQL Editor.
-- IMPORTANT: Before using the Admin Dashboard, set the intended admin user's
-- auth.users.raw_app_meta_data.role to 'admin' (instructions are at the bottom).

create extension if not exists pgcrypto;

-- ============================================================
-- 1. Per-user FundLedger data
-- ============================================================
create table if not exists public.contract_tracker_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{"contracts":[],"checks":[]}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.contract_tracker_data enable row level security;

drop policy if exists "Users can read own contract data" on public.contract_tracker_data;
drop policy if exists "Users can insert own contract data" on public.contract_tracker_data;
drop policy if exists "Users can update own contract data" on public.contract_tracker_data;

create policy "Users can read own contract data"
on public.contract_tracker_data for select
to authenticated
using (user_id = auth.uid());

create policy "Users can insert own contract data"
on public.contract_tracker_data for insert
to authenticated
with check (user_id = auth.uid());

create policy "Users can update own contract data"
on public.contract_tracker_data for update
to authenticated
using (user_id = auth.uid())
with check (user_id = auth.uid());

-- ============================================================
-- 2. Account restrictions used by Admin Dashboard
-- ============================================================
create table if not exists public.account_restrictions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  login_banned boolean not null default false,
  messages_blocked boolean not null default false,
  updated_at timestamptz not null default now()
);

alter table public.account_restrictions enable row level security;

-- Users do not receive direct table access. The app uses the RPCs below.
drop policy if exists "No direct account restriction access" on public.account_restrictions;

-- ============================================================
-- 3. Contact Us messages
-- ============================================================
create table if not exists public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  email text not null default '',
  message text not null,
  admin_reply text,
  created_at timestamptz not null default now(),
  replied_at timestamptz,
  conversation_status text not null default 'new'
    check (conversation_status in ('new','ongoing','saved'))
);

alter table public.contact_messages enable row level security;

-- Direct RLS access for a user's own messages is allowed. Admin operations use RPCs.
drop policy if exists "Users can read own messages" on public.contact_messages;
drop policy if exists "Users can insert own messages" on public.contact_messages;

create policy "Users can read own messages"
on public.contact_messages for select
to authenticated
using (user_id = auth.uid());

create policy "Users can insert own messages"
on public.contact_messages for insert
to authenticated
with check (user_id = auth.uid());

-- ============================================================
-- 4. Helper: is current user an admin
-- ============================================================
create or replace function public.is_fundledger_admin()
returns boolean
language sql
stable
security definer
set search_path = public, auth
as $$
  select coalesce((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin', false);
$$;

revoke all on function public.is_fundledger_admin() from public;
grant execute on function public.is_fundledger_admin() to authenticated;

-- ============================================================
-- 5. User restrictions RPCs
-- ============================================================
create or replace function public.get_my_account_restrictions()
returns table(login_banned boolean, messages_blocked boolean)
language sql
stable
security definer
set search_path = public, auth
as $$
  select
    coalesce(r.login_banned, false),
    coalesce(r.messages_blocked, false)
  from (select auth.uid() as user_id) u
  left join public.account_restrictions r on r.user_id = u.user_id;
$$;

create or replace function public.admin_get_user_restrictions(p_user_id uuid)
returns table(login_banned boolean, messages_blocked boolean)
language sql
stable
security definer
set search_path = public, auth
as $$
  select
    coalesce(r.login_banned, false),
    coalesce(r.messages_blocked, false)
  from (select p_user_id as user_id) u
  left join public.account_restrictions r on r.user_id = u.user_id
  where public.is_fundledger_admin();
$$;

create or replace function public.admin_set_user_login_banned(p_user_id uuid, p_banned boolean)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if not public.is_fundledger_admin() then
    raise exception 'Admin access required';
  end if;
  if p_user_id = auth.uid() then
    raise exception 'You cannot ban your own admin account';
  end if;
  insert into public.account_restrictions(user_id, login_banned, updated_at)
  values (p_user_id, p_banned, now())
  on conflict (user_id) do update
    set login_banned = excluded.login_banned,
        updated_at = now();
end;
$$;

create or replace function public.admin_set_user_messages_blocked(p_user_id uuid, p_blocked boolean)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if not public.is_fundledger_admin() then
    raise exception 'Admin access required';
  end if;
  insert into public.account_restrictions(user_id, messages_blocked, updated_at)
  values (p_user_id, p_blocked, now())
  on conflict (user_id) do update
    set messages_blocked = excluded.messages_blocked,
        updated_at = now();
end;
$$;

-- ============================================================
-- 6. Admin user list + selected user's FundLedger data
-- ============================================================
create or replace function public.admin_list_users()
returns table(id uuid, email text, created_at timestamptz)
language sql
stable
security definer
set search_path = public, auth
as $$
  select u.id, u.email::text, u.created_at
  from auth.users u
  where public.is_fundledger_admin()
  order by lower(coalesce(u.email, ''));
$$;

create or replace function public.admin_get_user_data(target_user_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public, auth
as $$
declare
  result jsonb;
begin
  if not public.is_fundledger_admin() then
    raise exception 'Admin access required';
  end if;

  select coalesce(c.data, '{"contracts":[],"checks":[]}'::jsonb)
    into result
  from public.contract_tracker_data c
  where c.user_id = target_user_id;

  return coalesce(result, '{"contracts":[],"checks":[]}'::jsonb);
end;
$$;

-- ============================================================
-- 7. Contact Us RPCs
-- ============================================================
create or replace function public.contact_list_my_messages()
returns setof public.contact_messages
language sql
stable
security definer
set search_path = public, auth
as $$
  select * from public.contact_messages
  where user_id = auth.uid()
  order by created_at desc;
$$;

create or replace function public.contact_admin_list_messages()
returns setof public.contact_messages
language sql
stable
security definer
set search_path = public, auth
as $$
  select * from public.contact_messages
  where public.is_fundledger_admin()
  order by created_at desc;
$$;

create or replace function public.contact_admin_reply_message(p_id uuid, p_reply text)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if not public.is_fundledger_admin() then
    raise exception 'Admin access required';
  end if;
  update public.contact_messages
     set admin_reply = nullif(trim(p_reply), ''),
         replied_at = case when nullif(trim(p_reply), '') is null then null else now() end,
         conversation_status = case when nullif(trim(p_reply), '') is null then conversation_status else 'ongoing' end
   where id = p_id;
end;
$$;

create or replace function public.contact_delete_message(p_id uuid)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  delete from public.contact_messages
   where id = p_id and user_id = auth.uid();
end;
$$;

create or replace function public.contact_admin_delete_message(p_id uuid)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if not public.is_fundledger_admin() then
    raise exception 'Admin access required';
  end if;
  delete from public.contact_messages where id = p_id;
end;
$$;

create or replace function public.contact_admin_set_conversation_status(p_user_id uuid, p_status text)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if not public.is_fundledger_admin() then
    raise exception 'Admin access required';
  end if;
  if p_status not in ('new','ongoing','saved') then
    raise exception 'Invalid conversation status';
  end if;
  update public.contact_messages
     set conversation_status = p_status
   where user_id = p_user_id;
end;
$$;

create or replace function public.contact_admin_delete_user_messages(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if not public.is_fundledger_admin() then
    raise exception 'Admin access required';
  end if;
  delete from public.contact_messages where user_id = p_user_id;
end;
$$;

create or replace function public.contact_delete_all_my_messages()
returns void
language sql
security definer
set search_path = public, auth
as $$
  delete from public.contact_messages where user_id = auth.uid();
$$;

create or replace function public.contact_admin_delete_all_messages()
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if not public.is_fundledger_admin() then
    raise exception 'Admin access required';
  end if;
  delete from public.contact_messages;
end;
$$;

-- ============================================================
-- 8. Permissions for RPCs
-- ============================================================
revoke all on function public.get_my_account_restrictions() from public;
revoke all on function public.admin_get_user_restrictions(uuid) from public;
revoke all on function public.admin_set_user_login_banned(uuid,boolean) from public;
revoke all on function public.admin_set_user_messages_blocked(uuid,boolean) from public;
revoke all on function public.admin_list_users() from public;
revoke all on function public.admin_get_user_data(uuid) from public;
revoke all on function public.contact_list_my_messages() from public;
revoke all on function public.contact_admin_list_messages() from public;
revoke all on function public.contact_admin_reply_message(uuid,text) from public;
revoke all on function public.contact_delete_message(uuid) from public;
revoke all on function public.contact_admin_delete_message(uuid) from public;
revoke all on function public.contact_admin_set_conversation_status(uuid,text) from public;
revoke all on function public.contact_admin_delete_user_messages(uuid) from public;
revoke all on function public.contact_delete_all_my_messages() from public;
revoke all on function public.contact_admin_delete_all_messages() from public;

-- Authenticated users can execute the RPCs; each RPC performs its own authorization.
grant execute on function public.get_my_account_restrictions() to authenticated;
grant execute on function public.admin_get_user_restrictions(uuid) to authenticated;
grant execute on function public.admin_set_user_login_banned(uuid,boolean) to authenticated;
grant execute on function public.admin_set_user_messages_blocked(uuid,boolean) to authenticated;
grant execute on function public.admin_list_users() to authenticated;
grant execute on function public.admin_get_user_data(uuid) to authenticated;
grant execute on function public.contact_list_my_messages() to authenticated;
grant execute on function public.contact_admin_list_messages() to authenticated;
grant execute on function public.contact_admin_reply_message(uuid,text) to authenticated;
grant execute on function public.contact_delete_message(uuid) to authenticated;
grant execute on function public.contact_admin_delete_message(uuid) to authenticated;
grant execute on function public.contact_admin_set_conversation_status(uuid,text) to authenticated;
grant execute on function public.contact_admin_delete_user_messages(uuid) to authenticated;
grant execute on function public.contact_delete_all_my_messages() to authenticated;
grant execute on function public.contact_admin_delete_all_messages() to authenticated;

-- ============================================================
-- 9. OPTIONAL: make an existing Auth user an admin
-- ============================================================
-- Replace the email below with the account that should be the MASTER ADMIN.
-- Run this separately after the main setup above if needed.
--
-- update auth.users
-- set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb
-- where email = 'YOUR-ADMIN-EMAIL@example.com';
--
-- The user should then sign out and sign back in so the new JWT contains role=admin.
